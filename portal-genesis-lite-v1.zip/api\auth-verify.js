import { COOKIE_NAME, makeSessionToken, parseCookies, sendJson } from "./_utils.js";

export default function handler(req, res) {
  const adminUser = process.env.ADMIN_USER || "admin";
  const cookies = parseCookies(req.headers?.cookie || "");
  const expected = makeSessionToken(adminUser);
  if (cookies[COOKIE_NAME] !== expected) {
    return sendJson(res, 401, { ok: false, error: "Sessao invalida." });
  }
  return sendJson(res, 200, { ok: true, user: adminUser });
}
