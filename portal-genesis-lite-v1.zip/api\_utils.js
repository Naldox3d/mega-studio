export const COOKIE_NAME = "mega_studio_session";

export function sendJson(res, status, data) {
  if (typeof res.status === "function" && typeof res.json === "function") {
    return res.status(status).json(data);
  }
  res.statusCode = status;
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  return res.end(JSON.stringify(data));
}

export async function readBody(req) {
  if (req.body && typeof req.body === "object") return req.body;
  if (typeof req.body === "string") {
    try {
      return JSON.parse(req.body || "{}");
    } catch {
      return {};
    }
  }

  return new Promise((resolve, reject) => {
    let body = "";
    req.on?.("data", (chunk) => {
      body += chunk;
      if (body.length > 1_000_000) {
        reject(new Error("Body muito grande."));
        req.destroy?.();
      }
    });
    req.on?.("end", () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch {
        resolve({});
      }
    });
    req.on?.("error", reject);
    if (!req.on) resolve({});
  });
}

export function parseCookies(cookieHeader = "") {
  return Object.fromEntries(
    String(cookieHeader)
      .split(";")
      .map((part) => part.trim())
      .filter(Boolean)
      .map((part) => {
        const index = part.indexOf("=");
        if (index === -1) return [part, ""];
        return [part.slice(0, index), decodeURIComponent(part.slice(index + 1))];
      })
  );
}

export function makeSessionToken(username) {
  const secret = process.env.SESSION_SECRET || "dev-secret";
  return Buffer.from(`${username}:${secret}`).toString("base64url");
}

export function sessionCookie(token, maxAge) {
  const secure = process.env.NODE_ENV === "production" ? "; Secure" : "";
  return `${COOKIE_NAME}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax${secure}; Max-Age=${maxAge}`;
}

export function providerStatus() {
  return {
    claude: {
      configured: Boolean(process.env.ANTHROPIC_API_KEY),
      env: "ANTHROPIC_API_KEY"
    },
    gemini: {
      configured: Boolean(process.env.GEMINI_API_KEY),
      env: "GEMINI_API_KEY"
    },
    flux: {
      configured: Boolean(process.env.POLLINATIONS_API_KEY),
      env: "POLLINATIONS_API_KEY"
    },
    pollinations: {
      configured: Boolean(process.env.POLLINATIONS_API_KEY),
      env: "POLLINATIONS_API_KEY"
    },
    ltx: {
      configured: Boolean(process.env.LTX_API_KEY),
      env: "LTX_API_KEY"
    },
    elevenlabs: {
      configured: Boolean(process.env.ELEVENLABS_API_KEY),
      env: "ELEVENLABS_API_KEY"
    }
  };
}

export function fallbackText(payload, reason = "API nao configurada.") {
  const type = payload.type || "text";
  const prompt = payload.prompt || "";
  const options = payload.options || {};

  if (type === "package") {
    return {
      ok: true,
      type: "package",
      provider: "local-fallback",
      package: {
        portal: "Portal Genesis Lite",
        type,
        reason,
        prompt,
        options,
        createdAt: new Date().toISOString(),
        checklist: [
          "Conferir briefing",
          "Escolher provider",
          "Gerar resultado",
          "Exportar TXT/JSON",
          "Salvar em banco na proxima fase"
        ]
      },
      warning: reason
    };
  }

  return {
    ok: true,
    type,
    provider: "local-fallback",
    warning: reason,
    text: [
      "PORTAL GENESIS LITE",
      "",
      `Tipo: ${type}`,
      `Motivo: ${reason}`,
      "",
      "Prompt recebido:",
      prompt || "-",
      "",
      "Saida local:",
      buildLocalOutput(type, prompt, options)
    ].join("\n")
  };
}

function buildLocalOutput(type, prompt, options) {
  if (type === "print") {
    return [
      "1. Copy curta para arte.",
      "2. Direcao visual com produto claro e area segura.",
      "3. Prompt Flux/Pollinations preparado.",
      "4. Checklist de pre-impressao: formato, margem, sangria e legibilidade.",
      "",
      `Formato: ${options.format || "4:5"} / Tamanho: ${options.size || "1080x1350"}`,
      `Base: ${prompt}`
    ].join("\n");
  }

  if (type === "video") {
    return [
      "1. Hook inicial.",
      "2. Cena de contexto.",
      "3. Prova visual.",
      "4. Oferta ou mensagem principal.",
      "5. CTA final.",
      "",
      `Duracao: ${options.duration || "15s"}`,
      `Base: ${prompt}`
    ].join("\n");
  }

  if (type === "image") {
    return [
      "Prompt visual preparado para Flux/Pollinations:",
      `${prompt}, professional commercial image, clean composition, realistic light, high quality, no watermark`
    ].join("\n");
  }

  if (type === "voice") {
    return [
      "Texto pronto para TTS:",
      prompt
    ].join("\n");
  }

  return [
    "Resumo:",
    prompt,
    "",
    "Estrutura:",
    "- Objetivo",
    "- Publico",
    "- Mensagem principal",
    "- Estilo",
    "- Entrega final"
  ].join("\n");
}
