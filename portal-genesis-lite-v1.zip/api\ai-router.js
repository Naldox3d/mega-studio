import { fallbackText, providerStatus, readBody, sendJson } from "./_utils.js";

export default async function handler(req, res) {
  if (req.method === "GET") {
    return sendJson(res, 200, {
      ok: true,
      name: "Portal Genesis Lite AI Router",
      providers: providerStatus(),
      routes: {
        router: "/api/ai-router",
        authLogin: "/api/auth-login",
        authVerify: "/api/auth-verify",
        authLogout: "/api/auth-logout"
      }
    });
  }

  if (req.method !== "POST") {
    return sendJson(res, 405, { ok: false, error: "Metodo nao permitido. Use POST." });
  }

  const payload = await readBody(req);
  const type = String(payload.type || "text").toLowerCase();
  const provider = pickProvider(type, String(payload.provider || "auto").toLowerCase());
  const prompt = String(payload.prompt || "").trim();

  if (!prompt) {
    return sendJson(res, 400, { ok: false, error: "Prompt vazio." });
  }

  try {
    if (provider === "claude") return sendJson(res, 200, await callClaude({ ...payload, type }));
    if (provider === "gemini") return sendJson(res, 200, await callGemini({ ...payload, type }));
    if (provider === "flux" || provider === "pollinations") return sendJson(res, 200, await callPollinations({ ...payload, type }));
    if (provider === "ltx") return sendJson(res, 200, await callLtx({ ...payload, type }));
    if (provider === "elevenlabs") return sendJson(res, 200, await callElevenLabs({ ...payload, type }));

    return sendJson(res, 200, fallbackText({ ...payload, type }, "Provider nao reconhecido."));
  } catch (error) {
    return sendJson(res, 200, fallbackText({ ...payload, type }, error.message || "Falha no provider."));
  }
}

function pickProvider(type, requested) {
  if (requested && requested !== "auto") {
    if (requested === "pollinations") return "pollinations";
    return requested;
  }

  if (type === "image") return "pollinations";
  if (type === "video") return "ltx";
  if (type === "voice") return "elevenlabs";
  if (type === "print") {
    if (process.env.ANTHROPIC_API_KEY) return "claude";
    if (process.env.GEMINI_API_KEY) return "gemini";
    return "local";
  }
  if (type === "package") return "local";

  if (process.env.ANTHROPIC_API_KEY) return "claude";
  if (process.env.GEMINI_API_KEY) return "gemini";
  return "local";
}

function systemFor(type) {
  if (type === "print") {
    return "Voce e o diretor de arte e pre-impressao do Portal Genesis. Gere copy curta, direcao visual, prompt de imagem, checklist tecnico e pacote de entrega para grafica.";
  }
  if (type === "video") {
    return "Voce e o roteirista de video do Portal Genesis. Gere cenas, prompts visuais, narracao, shot types, SRT e pacote para LTX/Remotion/CapCut.";
  }
  if (type === "image") {
    return "Voce e o prompt engineer visual do Portal Genesis. Gere prompt visual profissional, negative prompt e parametros de imagem.";
  }
  if (type === "voice") {
    return "Voce e o diretor de voz do Portal Genesis. Gere texto curto para TTS, tom, ritmo e pausas.";
  }
  return "Voce e o copiloto central do Portal Genesis Lite. Responda de forma pratica, organizada e pronta para producao.";
}

function buildPrompt(payload) {
  const options = payload.options || {};
  return [
    `Tipo: ${payload.type || "text"}`,
    `Formato: ${options.format || "livre"}`,
    `Qualidade: ${options.quality || "standard"}`,
    `Tamanho: ${options.size || "auto"}`,
    `Duracao: ${options.duration || "auto"}`,
    "",
    "Pedido:",
    payload.prompt
  ].join("\n");
}

async function callClaude(payload) {
  if (!process.env.ANTHROPIC_API_KEY) {
    return fallbackText(payload, "ANTHROPIC_API_KEY nao configurada.");
  }

  const model = payload.model || process.env.ANTHROPIC_MODEL || "claude-sonnet-4-5";
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01"
    },
    body: JSON.stringify({
      model,
      max_tokens: Number(payload.max_tokens || 3200),
      temperature: Number(payload.temperature ?? 0.55),
      system: systemFor(payload.type),
      messages: [{ role: "user", content: buildPrompt(payload) }]
    })
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    return fallbackText(payload, data.error?.message || "Claude respondeu erro.");
  }

  const text = Array.isArray(data.content)
    ? data.content.map((part) => part.text || "").join("\n")
    : "";

  return {
    ok: true,
    type: payload.type || "text",
    provider: "claude",
    model,
    text,
    usage: data.usage || null,
    raw: data
  };
}

async function callGemini(payload) {
  if (!process.env.GEMINI_API_KEY) {
    return fallbackText(payload, "GEMINI_API_KEY nao configurada.");
  }

  const model = payload.model || process.env.GEMINI_MODEL || "gemini-2.5-flash";
  const finalPrompt = `${systemFor(payload.type)}\n\n${buildPrompt(payload)}`;
  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-goog-api-key": process.env.GEMINI_API_KEY
    },
    body: JSON.stringify({
      contents: [{ role: "user", parts: [{ text: finalPrompt }] }],
      generationConfig: {
        temperature: Number(payload.temperature ?? 0.65),
        maxOutputTokens: Number(payload.max_tokens || payload.maxOutputTokens || 2600)
      }
    })
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    return fallbackText(payload, data.error?.message || "Gemini respondeu erro.");
  }

  const text = (data.candidates?.[0]?.content?.parts || [])
    .map((part) => part.text || "")
    .join("\n")
    .trim();

  return {
    ok: true,
    type: payload.type || "text",
    provider: "gemini",
    model,
    text,
    usage: data.usageMetadata || null,
    raw: data
  };
}

async function callPollinations(payload) {
  if (!process.env.POLLINATIONS_API_KEY) {
    return fallbackText(payload, "POLLINATIONS_API_KEY nao configurada.");
  }

  const options = payload.options || {};
  const size = normalizeSize(options.size || "1024x1024");
  const model = payload.model || process.env.POLLINATIONS_IMAGE_MODEL || "flux";
  const prompt = [
    payload.prompt,
    "professional commercial image, clean composition, realistic lighting, high quality",
    "Portal Genesis identity, premium finish",
    "no watermark, no fake logo, no unreadable text"
  ].join(", ");

  const params = new URLSearchParams({
    model,
    key: process.env.POLLINATIONS_API_KEY,
    width: String(size.width),
    height: String(size.height),
    seed: String(Number.isFinite(Number(payload.seed)) ? Number(payload.seed) : Math.floor(Math.random() * 2147483647)),
    nologo: "true",
    private: "true"
  });

  const url = `https://gen.pollinations.ai/image/${encodeURIComponent(prompt)}?${params.toString()}`;
  const image = await fetchImageAsDataUrl(url);

  return {
    ok: true,
    type: "image",
    provider: "pollinations",
    model,
    image,
    images: [{ dataUrl: image, provider: "pollinations", model }],
    prompt
  };
}

async function callLtx(payload) {
  if (!process.env.LTX_API_KEY) {
    return fallbackText(payload, "LTX_API_KEY nao configurada.");
  }

  const endpoint = process.env.LTX_API_URL || process.env.LTX_GENERATE_URL;
  if (!endpoint) {
    return fallbackText(payload, "Configure LTX_API_URL ou LTX_GENERATE_URL na Vercel.");
  }

  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${process.env.LTX_API_KEY}`
    },
    body: JSON.stringify({
      prompt: payload.prompt,
      options: payload.options || {},
      portal: "Portal Genesis Lite"
    })
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    return fallbackText(payload, data.error || data.message || "LTX respondeu erro.");
  }

  return {
    ok: true,
    type: "video",
    provider: "ltx",
    videoUrl: data.videoUrl || data.url || data.output?.url || data.result?.url || "",
    jobId: data.jobId || data.id || data.request_id || "",
    text: data.videoUrl || data.url ? "Video LTX gerado." : "Job LTX criado. Consulte o painel da API.",
    raw: data
  };
}

async function callElevenLabs(payload) {
  if (!process.env.ELEVENLABS_API_KEY) {
    return fallbackText(payload, "ELEVENLABS_API_KEY nao configurada.");
  }

  const voiceId = process.env.ELEVENLABS_VOICE_ID;
  if (!voiceId) {
    return fallbackText(payload, "ELEVENLABS_VOICE_ID nao configurado.");
  }

  const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(voiceId)}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "xi-api-key": process.env.ELEVENLABS_API_KEY
    },
    body: JSON.stringify({
      text: payload.prompt,
      model_id: process.env.ELEVENLABS_MODEL || "eleven_multilingual_v2",
      voice_settings: {
        stability: 0.45,
        similarity_boost: 0.78
      }
    })
  });

  if (!response.ok) {
    const text = await response.text().catch(() => "");
    return fallbackText(payload, text || "ElevenLabs respondeu erro.");
  }

  const arrayBuffer = await response.arrayBuffer();
  const audio = `data:audio/mpeg;base64,${Buffer.from(arrayBuffer).toString("base64")}`;

  return {
    ok: true,
    type: "voice",
    provider: "elevenlabs",
    audioUrl: audio,
    text: "Audio TTS gerado."
  };
}

function normalizeSize(size) {
  const match = String(size || "").toLowerCase().match(/^(\d{2,5})x(\d{2,5})$/);
  if (!match) return { width: 1024, height: 1024 };
  return {
    width: Math.max(256, Math.min(Number(match[1]), 2048)),
    height: Math.max(256, Math.min(Number(match[2]), 2048))
  };
}

async function fetchImageAsDataUrl(url) {
  const response = await fetch(url, {
    headers: { Accept: "image/png,image/jpeg,image/webp,*/*" }
  });

  if (!response.ok) {
    const text = await response.text().catch(() => "");
    throw new Error(`Pollinations falhou: ${response.status} ${text}`.trim());
  }

  const contentType = response.headers.get("content-type") || "image/png";
  if (!contentType.startsWith("image/")) {
    throw new Error(`Pollinations nao retornou imagem. Content-Type: ${contentType}`);
  }

  const buffer = Buffer.from(await response.arrayBuffer());
  return `data:${contentType};base64,${buffer.toString("base64")}`;
}
