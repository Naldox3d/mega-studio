# Estrutura simples recomendada

```txt
mega-studio/
├─ index.html
├─ package.json
├─ middleware.js
├─ api/
│  ├─ _utils.js
│  ├─ ai-router.js
│  ├─ auth-login.js
│  ├─ auth-logout.js
│  └─ auth-verify.js
└─ docs/
   └─ ESTRUTURA.md
```

## Proxima fase

Quando a base estiver funcionando:

```txt
api/storage-save.js       -> salvar historico no banco
api/storage-list.js       -> listar projetos
api/blob-upload.js        -> salvar imagens/videos
```

Sugestao:

- Vercel Blob para arquivos grandes.
- Supabase ou Vercel Postgres para projetos.
